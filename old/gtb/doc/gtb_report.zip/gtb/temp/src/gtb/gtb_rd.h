/*******************************************************************************
*
* GTB release 2.0 by Adrian Johnstone (A.Johnstone@rhul.ac.uk) 21 March 2003
*
* gtb_rd.h - recursive descent parser functions
*
* This file may be freely distributed. Please mail improvements to the author.
*
*******************************************************************************/
#ifndef GTB_RD_H
#define GTB_RD_H

void rd_grd_parse(grammar *this_gram, char *filename);
#endif

